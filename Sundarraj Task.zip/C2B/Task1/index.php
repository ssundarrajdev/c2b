<!-- Developer Name : Sundarraj S
Date : 21_07_2020 -->

<!DOCTYPE html>
<html>
    <head>
        <title>Employee Registration Form</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        
        <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,500;0,600;1,500&display=swap" rel="stylesheet">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" rel="stylesheet">
    </head>
    <body>
        <div class='row'>
            <div class='col-md-3'>
            </div>
            <div class='col-md-6'>
                <div class="_formDiv">
                    <div class="_headerDiv">
                        <h4 class="text-center h4 _headTitle">Employee Registration Form</h4>
                    </div>
                    <div class="_formDivBody">
                        <form id="addemp" method="post">
                            <div class="row">
                                <div class="_sizedBox _sizedBox10"></div>
                                <div class="col-md-6">
                                    <!-- <label class="_label">Full Name :</label> -->
                                    <input type="text" title="Enter Name : " required class="_ipt" name='fullname' placeholder="Enter Name : " />
                                </div>
                                <div class="col-md-6">
                                    <!-- <label class="_label">Father Name :</label> -->
                                    <input type="text" required class="_ipt" name='fathername'  placeholder="Enter Father Name : " />
                                </div>
                                <div class="col-md-6">
                                    <!-- <label class="_label">Father Name :</label> -->
                                    <input type="text" pattern="[789][0-9]{9}" title="Example : 9999999999" required class="_ipt" name='mobileno'  placeholder="Enter Mobile No : " />
                                </div>
                                <div class="col-md-6">
                                    <!-- <label class="_label">Father Name :</label> -->
                                    <input type="text" required class="_ipt" name='email'  placeholder="Enter Email Address : " />
                                </div>
                                <div class="col-md-12">
                                    <!-- <label class="_label">Father Name :</label> -->
                                    <textarea type="text" required class="_ipt" name='address' placeholder="Enter Address : "></textarea>
                                </div>
                                <div class="col-md-6">
                                    <!-- <label class="_label">Father Name :</label> -->
                                    <input type="text" required class="_ipt" name='qualification'  placeholder="Enter Qualification : " />
                                </div>
                                <div class="col-md-6">
                                    <!-- <label class="_label">Father Name :</label> -->
                                    <select required type="text" class="_ipt" name='experience'>
                                        <option value="">Select Experience</option>
                                        <option value="Fresher">Fresher</option>
                                        <option value="0 > 1">0 > 1</option>
                                        <option value="1 < 2">1 < 2</option>
                                        <option value="Other">Other</option>
                                    </select>   
                                </div>
                                <div class="col-md-12">
                                    <label class="_label" id="resumelabel">Resume : <small class="error"></small></label>
                                    <input required id='resume' onchange="checkValidFile(this.id)" type="file" class="_ipt" name='resume'  />
                                </div>
                                <div class="col-md-12">
                                    <input required type="text" class="_ipt" name='skill'  placeholder="Enter Skill : " />
                                </div>
                                <div class="col-md-6">
                                    <!-- <label class="_label">Father Name :</label> -->
                                    <input required type="text" class="_ipt" name='designation'  placeholder="Enter Designation : " />
                                </div>
                                <div class="col-md-6">
                                    <!-- <label class="_label">Father Name :</label> -->
                                    <input required type="text" class="_ipt" name='salary'  placeholder="Enter Month Salary : " />
                                </div>
                                <div class="col-md-6">
                                    <!-- <label class="_label">Father Name :</label> -->
                                    <input required type="date" class="_ipt" name='joindate'  placeholder="Enter Join Date : " />
                                </div>
                                <div class="col-md-12">
                                    <div class="_sizedBox _sizedBox10"></div>
                                    <center><input type="submit" class="submit" /></center>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                 
            </div>
            <div class='col-md-3'>
                
            </div>
        </div>

        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
        <script src="js/myfunction.js"></script>
    </body>
</html>