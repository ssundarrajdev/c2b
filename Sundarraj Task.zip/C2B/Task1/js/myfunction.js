

$("#empadd").submit(function(event){
    event.preventDefault();
    alert('Hi');
})

function checkValidFile(id){
    $('.error').text('');
    var fileExtension = ['pdf'];
    if ($.inArray($('#'+id).val().split('.').pop().toLowerCase(), fileExtension) == -1) { 
        $("#"+id).val('');
        $('.error').text('Select Pdf File Only');
    }
}
