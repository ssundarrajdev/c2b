<?php
    include 'widgets/header.php';
?>
<?php
    include 'widgets/sidebar.php';
?>
<main>
    <div class="container-fluid">
    <div style='height:50px;'></div>
            <div class="card mb-4">
            <div class="card-header">
                
                Stock Details
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>S.No</th>
                                <th>Name</th>
                                <th>IN</th>
                                <th>OUT</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>1</td>
                                <td>Milk Packet</td>
                                <td>In : 10<br><input placeholder='Enter Count : ' type='number'/><button class='stockbtn btn-success'>Update</button></td>
                                <td>Out : 1<br><input placeholder='Enter Count : ' type='number'/><button class='stockbtn btn-success'>Update</button></td>
                                <td>
                                    <a class='btn'><i class='fa fa-trash'></i></a>
                                    <a class='btn'><i class='fa fa-edit'></i></a>
                                </td>
                                
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</main>
<?php
    include 'widgets/footer.php';
?>