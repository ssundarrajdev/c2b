
(function($) {
    "use strict";

    // Add active state to sidbar nav links
    var path = window.location.href; // because the 'href' property of the DOM element is the absolute path
        $("#layoutSidenav_nav .sb-sidenav a.nav-link").each(function() {
            if (this.href === path) {
                $(this).addClass("active");
            }
        });

    // Toggle the side navigation
    $("#sidebarToggle").on("click", function(e) {
        e.preventDefault();
        $("body").toggleClass("sb-sidenav-toggled");
    });
})(jQuery);

$("#passwordupdate").submit(function(event){
    event.preventDefault();
    var pass1 = $('.password1').val();
    var pass2 = $('.password2').val();

    if(pass1 == pass2){
        swal({
            title: "Are you sure",
            text: "",
            type: "info",
            showCancelButton: true,
            closeOnConfirm: false,
            confirmButtonText: "Yes",
            cancelButtonText: "No",
            showLoaderOnConfirm: true
          }, function () {
            setTimeout(function () {
              swal("Password Updated");
            }, 2000);
          });
    }else{
        
        $('.error').text('Password Not Matched');
    }
})

$('.password1').on('change',function () {
    $('.error').text('');
})
$('.password2').on('change',function () {
    $('.error').text('');
})


$("#addincomeform").submit(function(event){
    event.preventDefault();
    $('#addincome').modal('hide');
    swal({
        title: "Are you sure",
        text: "",
        type: "info",
        showCancelButton: true,
        closeOnConfirm: false,
        confirmButtonText: "Yes",
        cancelButtonText: "No",
        showLoaderOnConfirm: true
      }, function () {
        setTimeout(function () {
          swal("Submit Successfully");
        }, 2000);
      });
})

$("#addexpensesform").submit(function(event){
    event.preventDefault();
    $('#addexpenses').modal('hide');
    swal({
        title: "Are you sure",
        text: "",
        type: "info",
        showCancelButton: true,
        closeOnConfirm: false,
        confirmButtonText: "Yes",
        cancelButtonText: "No",
        showLoaderOnConfirm: true
      }, function () {
        setTimeout(function () {
          swal("Submit Successfully");
        }, 2000);
      });
})

$("#addsalesform").submit(function(event){
    event.preventDefault();
    $('#addsales').modal('hide');
    swal({
        title: "Are you sure",
        text: "",
        type: "info",
        showCancelButton: true,
        closeOnConfirm: false,
        confirmButtonText: "Yes",
        cancelButtonText: "No",
        showLoaderOnConfirm: true
      }, function () {
        setTimeout(function () {
          swal("Submit Successfully");
        }, 2000);
      });
})

$("#addotherincomeform").submit(function(event){
    event.preventDefault();
    $('#addotherincome').modal('hide');
    swal({
        title: "Are you sure",
        text: "",
        type: "info",
        showCancelButton: true,
        closeOnConfirm: false,
        confirmButtonText: "Yes",
        cancelButtonText: "No",
        showLoaderOnConfirm: true
      }, function () {
        setTimeout(function () {
          swal("Submit Successfully");
        }, 2000);
      });
})

$("#addpayoutsform").submit(function(event){
    event.preventDefault();
    $('#addpayouts').modal('hide');
    swal({
        title: "Are you sure",
        text: "",
        type: "info",
        showCancelButton: true,
        closeOnConfirm: false,
        confirmButtonText: "Yes",
        cancelButtonText: "No",
        showLoaderOnConfirm: true
      }, function () {
        setTimeout(function () {
          swal("Submit Successfully");
        }, 2000);
      });
})

$("#addpurchaseorderform").submit(function(event){
    event.preventDefault();
    $('#addpurchaseorder').modal('hide');
    swal({
        title: "Are you sure",
        text: "",
        type: "info",
        showCancelButton: true,
        closeOnConfirm: false,
        confirmButtonText: "Yes",
        cancelButtonText: "No",
        showLoaderOnConfirm: true
      }, function () {
        setTimeout(function () {
          swal("Submit Successfully");
        }, 2000);
      });
})