<?php
    include 'widgets/header.php';
?>
<?php
    include 'widgets/sidebar.php';
?>
<main>
    <div class="container-fluid">
         <div style='height:50px;'></div>
            <div class="card mb-4">
            <div class="card-header">
                Other Expenses
            </div>
            <div class="card-body">
                <div class="row">
                    
                </div>
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>S.No</th>
                                <th>Date</th>
                                <th>Id</th>
                                <th>Source</th>
                                <th>Amount</th>
                                <th>Description</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>1</td>
                                <td>21-07-2020</td>
                                <td>IN123</td>
                                <td>Rent</td>
                                <td>1000</td>
                                <td>Rent of Werehouse</td>
                                <td>
                                    <a class='btn'><i class='fa fa-trash'></i></a>
                                    <a class='btn'><i class='fa fa-edit'></i></a>
                                </td>
                            </tr>
                            <tr>
                                <td>2</td>
                                <td>21-07-2020</td>
                                <td>IN123</td>
                                <td>Rent</td>
                                <td>1000</td>
                                <td>Office of Werehouse</td>
                                <td>
                                    <a class='btn'><i class='fa fa-trash'></i></a>
                                    <a class='btn'><i class='fa fa-edit'></i></a>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</main>
<?php
    include 'widgets/footer.php';
?>