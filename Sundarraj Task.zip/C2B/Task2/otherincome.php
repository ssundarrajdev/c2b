<?php
    include 'widgets/header.php';
?>
<?php
    include 'widgets/sidebar.php';
?>
<main>
    <div class="container-fluid">
         <div style='height:50px;'></div>
            <div class="card mb-4">
            <div class="card-header">
                
                <div class="row">
                    <div class="col-md-10">
                        Other Income
                    </div>
                    <div class="col-md-2">
                        <button class='w-100 btn-success' data-toggle="modal" data-target="#addotherincome">Add Other Income</button>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <div class="row">
                    
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>S.No</th>
                                <th>Date</th>
                                <th>Id</th>
                                <th>Source</th>
                                <th>Details</th>
                                <th>Amount</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>1</td>
                                <td>21-07-2020</td>
                                <td>IN123</td>
                                <td>Sale</td>
                                <td>N/A</td>
                                <td>100</td>
                                <td>
                                    <a class='btn'><i class='fa fa-trash'></i></a>
                                    <a class='btn'><i class='fa fa-edit'></i></a>
                                </td>
                            </tr>
                            <tr>
                                <td>2</td>
                                <td>22-07-2020</td>
                                <td>IN123</td>
                                <td>Ads</td>
                                <td>N/A</td>
                                <td>100</td>
                                <td>
                                    <a class='btn'><i class='fa fa-trash'></i></a>
                                    <a class='btn'><i class='fa fa-edit'></i></a>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</main>


<!-- Modal -->
<div class="modal fade" id="addotherincome" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <form id="addotherincomeform">
        <div class="modal-header">
          <h4 class="modal-title">Add Other Income</h4>
        </div>
        <div class="modal-body">
            <div class="row">
                <div class="col-md-12">
                    <label>Date : </label>
                    <input type="date" required="" placeholder="Enter Date : " name="incomedate" class="ipt incomedate">
                </div>
                <div class="col-md-12">
                    <label>Id : </label>
                    <input type="text" required="" placeholder="Enter Id : " name="incomeid" class="ipt incomeid">
                </div>
                <div class="col-md-12">
                    <label>Source : </label>
                    <input type="text" required="" placeholder="Enter Source : " name="incomesource" class="ipt incomesource">
                </div>
                <div class="col-md-12">
                    <label>Details : </label>
                    <input type="text" required="" placeholder="Enter Details : " name="incomedetails" class="ipt incomedetails">
                </div>
                <div class="col-md-12">
                    <label>Amount : </label>
                    <input type="text" required="" placeholder="Enter Amount : " name="incomeamount" class="ipt incomeamount">
                </div>
            </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn" data-dismiss="modal">Close</button>
          <input type="submit" class="btn btn-success">
        </div>
        </form>
      </div>
      
    </div>
</div>

<?php
    include 'widgets/footer.php';
?>