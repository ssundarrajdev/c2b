<?php
    include 'widgets/header.php';
?>
<?php
    include 'widgets/sidebar.php';
?>
<main>
    <div class="container-fluid">
         <div style='height:50px;'></div>
            <div class="card mb-4">
            <div class="card-header">
                
                <div class="row">
                    <div class="col-md-10">
                        Payouts
                    </div>
                    <div class="col-md-2">
                        <button class='w-100 btn-success' data-toggle="modal" data-target="#addpayouts">Add Payouts</button>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <div class="row">
                    
                </div>
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>S.No</th>
                                <th>Date</th>
                                <th>Employee Id</th>
                                <th>Employee Name</th>
                                <th>Amount</th>
                                <th>Notes</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>1</td>
                                <td>21-07-2020</td>
                                <td>IN123</td>
                                <td>Raj</td>
                                <td>100</td>
                                <td>-</td>
                                <td>
                                    <a class='btn'><i class='fa fa-trash'></i></a>
                                    <a class='btn'><i class='fa fa-edit'></i></a>
                                </td>
                            </tr>
                            <tr>
                            <td>1</td>
                                <td>21-07-2020</td>
                                <td>IN124</td>
                                <td>RajKumar</td>
                                <td>100</td>
                                <td>-</td>
                                <td>
                                    <a class='btn'><i class='fa fa-trash'></i></a>
                                    <a class='btn'><i class='fa fa-edit'></i></a>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</main>

<!-- Modal -->
<div class="modal fade" id="addpayouts" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <form id="addpayoutsform">
        <div class="modal-header">
          <h4 class="modal-title">Add Payouts</h4>
        </div>
        <div class="modal-body">
            <div class="row">
                <div class="col-md-12">
                    <label>Date : </label>
                    <input type="date" required="" placeholder="Enter Date : " name="incomedate" class="ipt payoutdate">
                </div>
                <div class="col-md-12">
                    <label>Employee Id : </label>
                    <input type="text" required="" placeholder="Enter Employee Id : " name="employeeid" class="ipt employeeid">
                </div>
                <div class="col-md-12">
                    <label>Employee Name : </label>
                    <input type="text" required="" placeholder="Enter Employee Name : " name="employeename" class="ipt employeename">
                </div>
                <div class="col-md-12">
                    <label>Amount : </label>
                    <input type="text" required="" placeholder="Enter Amount : " name="payamount" class="ipt incomeamount">
                </div>
                <div class="col-md-12">
                    <label>Notes : </label>
                    <input type="text" required="" placeholder="Enter Notes : " name="notes" class="ipt notes">
                </div>
            </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn" data-dismiss="modal">Close</button>
          <input type="submit" class="btn btn-success">
        </div>
        </form>
      </div>
      
    </div>
</div>

<?php
    include 'widgets/footer.php';
?>