<?php
    include 'widgets/header.php';
?>
<?php
    include 'widgets/sidebar.php';
?>
<main>
    <div class="container-fluid">
         <div style='height:50px;'></div>
            <div class="card mb-4">
            <div class="card-header">
               
                <div class="row">
                    <div class="col-md-10">
                        Sales
                    </div>
                    <div class="col-md-2">
                        <button class='w-100 btn-success' data-toggle="modal" data-target="#addsales">Add Sales</button>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <div class="row">
                    
                </div>
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>S.No</th>
                                <th>Date</th>
                                <th>Invoice</th>
                                <th>Service</th>
                                <th>Items</th>
                                <th>Amount</th>
                                <th>Customer Name</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>1</td>
                                <td>21-07-2020</td>
                                <td>IN123</td>
                                <td>N/A</td>
                                <td>T-Shirt</td>
                                <td>100</td>
                                <td>Raj</td>
                                <td>
                                    <a class='btn'><i class='fa fa-trash'></i></a>
                                    <a class='btn'><i class='fa fa-edit'></i></a>
                                </td>
                            </tr>
                            <tr>
                                <td>1</td>
                                <td>21-07-2020</td>
                                <td>IN123</td>
                                <td>N/A</td>
                                <td>T-Shirt</td>
                                <td>100</td>
                                <td>Raj</td>
                                <td>
                                    <a class='btn'><i class='fa fa-trash'></i></a>
                                    <a class='btn'><i class='fa fa-edit'></i></a>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</main>


<!-- Modal -->
<div class="modal fade" id="addsales" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <form id="addsalesform">
        <div class="modal-header">
          <h4 class="modal-title">Add Sales</h4>
        </div>
        <div class="modal-body">
            <div class="row">
                <div class="col-md-12">
                    <label>Date : </label>
                    <input type="date" required="" placeholder="Enter Date : " name="incomedate" class="ipt incomedate">
                </div>
                <div class="col-md-12">
                    <label>Invoice : </label>
                    <input type="text" required="" placeholder="Enter Invoice : " name="invoice" class="ipt invoice">
                </div>
                <div class="col-md-12">
                    <label>Service : </label>
                    <input type="text" required="" placeholder="Enter Service : " name="incomesource" class="ipt incomesource">
                </div>
                <div class="col-md-12">
                    <label>Items : </label>
                    <input type="text" required="" placeholder="Enter Items : " name="items" class="ipt items">
                </div>
                <div class="col-md-12">
                    <label>Amount : </label>
                    <input type="text" required="" placeholder="Enter Amount : " name="amount" class="ipt amount">
                </div>
                <div class="col-md-12">
                    <label>Customer Name : </label>
                    <input type="text" required="" placeholder="Enter Customer Name : " name="customername" class="ipt customername">
                </div>
            </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn" data-dismiss="modal">Close</button>
          <input type="submit" class="btn btn-success">
        </div>
        </form>
      </div>
      
    </div>
</div>

<?php
    include 'widgets/footer.php';
?>