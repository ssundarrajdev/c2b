<?php
    include 'widgets/header.php';
?>
<?php
    include 'widgets/sidebar.php';
?>
<main>
    <div class="container-fluid">
        <div style='height:50px;'></div>
        <div class="card mb-4">
        <div class="card-header">
            Password Update <small style='color:red;' class='error'></small>
        </div>
        <div class="card-body">
            <form id='passwordupdate'>
                <div class='row'>
                    <div class='col-md-4'>
                        <label>Enter Password : </label>
                        <input type="password" required placeholder="Enter Enter Password : " name="password1" class="ipt password1" />
                    </div>
                    <div class='col-md-4'>
                        <label>Re-Enter Password : </label>
                        <input type="password" required placeholder="Enter Re-Enter Password : " min='0' name="password2" class="ipt password2" />
                    </div>
                    
                    <div class='col-md-4'>
                        <div style="height:33px"></div>
                        <input type='submit' class='btn btn-success w-100' value='Update My Password' />
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<?php
    include 'widgets/footer.php';
?> 