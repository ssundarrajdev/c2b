<!DOCTYPE html>
<html lang="en">
<head>
  <title>Health Insurance Plans, Medical Insurance, Health Insurance Policies</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <link href="https://fonts.googleapis.com/css2?family=Roboto+Slab:wght@400;500&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="css/style.css">
  <!-- Owl Stylesheets -->
  <link rel="stylesheet" href="css/owl.carousel.min.css">
  <link rel="stylesheet" href="css/owl.theme.default.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
<div class="topnav">
    <div class="container">
        <div class="row">
            <div class='col-md-6 col-sm-6'>
                <P class='topnavtext tleft'><i class='fa fa-phone'></i> +919629904769</p>
            </div>
            <div class='col-md-6 col-sm-6'>
                <P class='topnavtext tright'><i class='fa fa-home'></i> T-Nagar Chennai</p>
            </div>
        </div>
    </div>
</div>
<nav class="navbar">
  <div class="container-fluid container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="#">C2B Tech</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav navbar-right">
        <li><a href="#"> Home</a></li>
        <li><a href="#"> Plan</a></li>
        <li><a href="#"> About Us</a></li>
        <li><a href="#"> Contact Us</a></li>
      </ul>
    </div>
  </div>
</nav>
<div class='main'>
    <div class='heroBanner'>
        <div class="row">
            <!-- <div class="col-md-3"></div> -->
            <div class='container'>
            <div class="col-md-8 npm">
                
                    <div class='herotext'>
                        <h1 class='cfont fP text-left'>Health Insurance Plans</h1>
                        <p class='cfont fP text-left'>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the </p>
                    </div>
                
            </div>
            <div class="col-md-4"></div>
            </div>
        </div>
    </div>
    <div class="plan" id="plan">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h1 class='text-center cfont'>Recommended Plans</h1>
                    <p class='text-center cfont'>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                    <hr>
                </div>
                <div class="col-md-4">
                    <center>
                        <div class="planbox">
                            <div class="planimg">
                                <img src="image/p1.svg" />
                            </div>
                            <div class="plantitle">
                                <h4 class='text-center cfont'>Plan 1</h4>
                                <p class='text-center cfont'>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
                            </div>
                            <div class="plantitle">
                                <button class='btn planbtn'>BUY NOW</button>
                            </div>
                        </div>
                    </center>
                </div>
                <div class="col-md-4">
                    <center>
                        <div class="planbox">
                            <div class="planimg">
                                <img src="image/p1.svg" />
                            </div>
                            <div class="plantitle">
                                <h4 class='text-center cfont'>Plan 2</h4>
                                <p class='text-center cfont'>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
                            </div>
                            <div class="plantitle">
                                <button class='btn planbtn'>BUY NOW</button>
                            </div>
                        </div>
                    </center>
                </div>
                <div class="col-md-4">
                    <center>
                        <div class="planbox">
                            <div class="planimg">
                                <img src="image/p1.svg" />
                            </div>
                            <div class="plantitle">
                                <h4 class='text-center cfont'>Plan 3</h4>
                                <p class='text-center cfont'>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
                            </div>
                            <div class="plantitle">
                                <button class='btn planbtn'>BUY NOW</button>
                            </div>
                        </div>
                    </center>
                </div>
                <div class="col-md-4">
                    <center>
                        <div class="planbox">
                            <div class="planimg">
                                <img src="image/p1.svg" />
                            </div>
                            <div class="plantitle">
                                <h4 class='text-center cfont'>Plan 4</h4>
                                <p class='text-center cfont'>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
                            </div>
                            <div class="plantitle">
                                <button class='btn planbtn'>BUY NOW</button>
                            </div>
                        </div>
                    </center>
                </div>
                <div class="col-md-4">
                    <center>
                        <div class="planbox">
                            <div class="planimg">
                                <img src="image/p1.svg" />
                            </div>
                            <div class="plantitle">
                                <h4 class='text-center cfont'>Plan 5</h4>
                                <p class='text-center cfont'>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
                            </div>
                            <div class="plantitle">
                                <button class='btn planbtn'>BUY NOW</button>
                            </div>
                        </div>
                    </center>
                </div>
                <div class="col-md-4">
                    <center>
                        <div class="planbox">
                            <div class="planimg">
                                <img src="image/p1.svg" />
                            </div>
                            <div class="plantitle">
                                <h4 class='text-center cfont'>Plan 6</h4>
                                <p class='text-center cfont'>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
                            </div>
                            <div class="plantitle">
                                <button class='btn planbtn'>BUY NOW</button>
                            </div>
                        </div>
                    </center>
                </div>
            </div>
        </div>
    </div>
    <div class="client">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h1 class='text-center cfont'>Our Clients</h1>
                    <p class='text-center cfont'>Check what our customers are saying about our product. They are very happy with their purchase</p>
                    <hr>
                </div>
                <div class="col-md-12">
                    <div class="carousel-wrap">
                        <div class="owl-carousel owl-theme">
                            <div class="item">
                                <div class="col-md-12">
                                    <center>
                                        <div class="iconDIv">
                                            <i class='fa fa-quote-right'></i>
                                        </div>
                                        <div class="clienttext">
                                            <p class='text-center cfont'>I want to congratulate the entire C2B Support Team, for having such a good support.</p>
                                        </div>
                                        <div class="clientname">
                                            <h4 class='text-center  cfont'>- Raj</h4>
                                        </div>
                                    </center>
                                </div>
                            </div>
                            <div class="item">
                                <div class="col-md-12">
                                    <center>
                                        <div class="iconDIv">
                                            <i class='fa fa-quote-right'></i>
                                        </div>
                                        <div class="clienttext">
                                            <p class='text-center cfont'>I want to congratulate the entire C2B Support Team, for having such a good support.</p>
                                        </div>
                                        <div class="clientname">
                                            <h4 class='text-center  cfont'>- Raj</h4>
                                        </div>
                                    </center>
                                </div>
                            </div>
                            <div class="item">
                                <div class="col-md-12">
                                    <center>
                                        <div class="iconDIv">
                                            <i class='fa fa-quote-right'></i>
                                        </div>
                                        <div class="clienttext">
                                            <p class='text-center cfont'>I want to congratulate the entire C2B Support Team, for having such a good support.</p>
                                        </div>
                                        <div class="clientname">
                                            <h4 class='text-center  cfont'>- Raj</h4>
                                        </div>
                                    </center>
                                </div>
                            </div>
                            <div class="item">
                                <div class="col-md-12">
                                    <center>
                                        <div class="iconDIv">
                                            <i class='fa fa-quote-right'></i>
                                        </div>
                                        <div class="clienttext">
                                            <p class='text-center cfont'>I want to congratulate the entire C2B Support Team, for having such a good support.</p>
                                        </div>
                                        <div class="clientname">
                                            <h4 class='text-center  cfont'>- Raj</h4>
                                        </div>
                                    </center>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<footer class="container-fluid text-center footer">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <h4 class='cfont footertitle'>About us</h4>
                <p class='footertext cfont'>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
            </div>
            <div class="col-md-3">
                <h4 class='cfont footertitle'>Quick Link</h4>
                <ul>
                    <li>Home</li>
                    <li>Service</li>
                    <li>About us</li>
                    <li>Contact us</li>
                    <li>Login</li>
                </ul>
            </div>
            <div class="col-md-3">
                <h4 class='cfont footertitle'>Contact Us</h4>
                <ul>
                    <li><i class='fa fa-home'></i> Chennai Pincode : 6222222</li>
                    <li><i class='fa fa-phone'></i> +919629904769</li>
                    <li><i class='fa fa-envelope'></i> info@c2btech.com</li>
                   
                </ul>
            </div>
            
            <div class='col-md-12'>
                <div class='bottomfooter'>
                    <div class="container">
                        <p>© 2020 All Rights Reserved . C2B Tech</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>


<script src="js/owl.carousel.js"></script>
<script>
    $('.owl-carousel').owlCarousel({
        margin: 20,
        nav: true,
        autoplay:true,
        navText:["<div class='nav-btn prev-slide'></div>","<div class='nav-btn next-slide'></div>"],
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 3
            },
            1000: {
                items: 3
            }
        }
    });
</script>
</body>
</html>
